Before do
	@aruba_timeout_seconds = 7 
	#@aruba_io_wait_seconds =  12
end
