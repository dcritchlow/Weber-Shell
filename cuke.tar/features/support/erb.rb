Before do
	#@aruba_timeout_seconds = 15 
	#@aruba_io_wait_seconds =  12
end
